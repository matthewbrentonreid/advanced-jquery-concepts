<?php
$arrColors = array('FF0000','FF0076', '0019FF', '00C3FF', '00FFBC', '6CFF3F', 'FFFF00', 'FFA200', 'FFFFFF', '000000');

echo json_encode($arrColors);
?>